# Simple CRUD MySQL
Simple CRUD Android Studio using Database MySQLMenggunakan REST

<pre>
<img src="Screenshot_1.png" width="250" height="444">     <img src="Screenshot_2.png" width="250" height="444">     <img src="Screenshot_3.png" width="250" height="444">

<img src="Screenshot_4.png" width="250" height="444">     <img src="Screenshot_5.png" width="250" height="444">     <img src="Screenshot_6.png" width="250" height="444">

<img src="Screenshot_7.png" width="250" height="444">
</pre>
